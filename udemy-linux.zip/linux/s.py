from selenium import webdriver
import time
import sys
import os
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from threading import Thread
import smtplib
import requests
from pyvirtualdisplay import Display

kmiko = 0
display = Display(visible=0, size=(800, 600))
display.start()

lines = []
f23 = open('url.txt', 'r')
fooler23 = f23.read().splitlines()
noofurlj = len(fooler23)
with open('acc.txt', 'r') as f:
    for line in f.readlines():
        l,name = line.strip().split(';')
        lines.append((l,name))

counterr=0
majorb = 0
k = 1
kiopl = 0
kijo = 0

def urll():
    global fooler23
    global kijo
    global max_time
    global start_time
    global noofurlj
    if kijo == noofurlj :
        kijo = 0
        jupo2 = fooler23[kijo]
    else :
        jupo2 = fooler23[kijo]
    pk1 = jupo2.split(',')
    if (time.time() - start_time) < max_time :
        kijo = kijo + 1
    return pk1

def fetcher():
    global fooler
    global kiopl
    global noofproxy
    if kiopl == noofproxy :
        kiopl = 0
        jupo = fooler[kiopl]
    else :
        jupo = fooler[kiopl]
    kiopl = kiopl + 1
    return jupo

def sec():
    global k
    global inst8
    global huds
    global majorb
    global start_time
    global max_time
    global counterr
    global l
    global lines
    global checkproxy
    global kanta
    global kmiko
    urler2 = urll()
    kmiko = kmiko + 1
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.add_argument('--disable-extensions')
    chromeOptions.add_argument('--disable-setuid-sandbox')
    chromeOptions.add_argument('--no-sandbox')
    if checkproxy == '1':
        PROXY = fetcher()
        chromeOptions.add_argument("ignore-certificate-errors")
        chromeOptions.add_argument("--ignore-ssl-errors")
        pipok='--proxy-server=http://'+PROXY
        chromeOptions.add_argument(pipok)
    driver = webdriver.Chrome('/root/Desktop/linux/cd', chrome_options=chromeOptions)
    driver.get('https://accounts.spotify.com/en-US/login?continue=https:%2F%2Fwww.spotify.com%2Fus%2Faccount%2Foverview%2F')
    njii = inst8
    uikn = lines[k]
    useracc1 = uikn[0]
    passlk = uikn[1]
    k = k+1
    sumop = driver.find_element_by_css_selector('#login-username')
    sumop.send_keys(useracc1)
    kij = driver.find_element_by_css_selector('#login-password')
    kij.send_keys(passlk)
    time.sleep(1)
    kij.submit()
    time.sleep(3)
    print("instance no . "+str(kmiko))
    while (majorb < 100000):
        urler = urler2[0]
        timex = int(urler2[1])
        driver.get(urler)
        time.sleep(3)
        tms = urler2[1]
        try:
            driver.find_element_by_css_selector('button.btn:nth-child(3)').click()
        except NoSuchElementException:
            time.sleep(5)
            driver.find_element_by_css_selector('button.btn:nth-child(3)').click()
        time.sleep(timex)
        counterr = counterr + 1
        print('Times runned :' + str(counterr))
        while (time.time() - start_time) < max_time :
            try:
                driver.find_element_by_css_selector('button.btn:nth-child(3)').click()
                time.sleep(timex)
                counterr = counterr + 1
                print('Times runned :' + str(counterr))
            except NoSuchElementException:
                time.sleep(5)
                driver.find_element_by_css_selector('button.btn:nth-child(3)').click()
                time.sleep(timex)
                counterr = counterr + 1
                print('Times runned :' + str(counterr))
        majorb = majorb+1
        if kmiko == kanta:
            mailme()
    driver.quit()

def mailme():
    global max_time
    global counterr
    msgss = ("End of "+str(max_time)+" seconds. Have a nice day.Total count "+str(counterr))
    requests.post('https://api.telegram.org/bot535873984:AAFVMtcZ0YkTUZDN780k9GM1C24NIsQBS8M/sendmessage?text=' + msgss +'MESSAGEBODY&chat_id=328079626')

def timeee():
    global inst8
    global head
    global timmy
    global max_time
    global start_time
    indie()
    timely = timmy
    max_time = timely * 60
    start_time = time.time()
    variabllo = inst8
    headrj = int(head)
    miop = input("Do u confirm? (y/n)  ")
    if miop == 'y':
        while variabllo != 0:
            tkkl = Thread(target=sec,)
            tkkl.start()
            time.sleep(headrj)
            variabllo = variabllo-1

f = open('proxy.txt', 'r')
fooler = f.read().splitlines()
noofproxy = len(fooler)
huio = '1'
if huio == '1':
    timmy = input('Please enter time of loop in min  : ')
    timmy=int(timmy)
    inst8 = input('Please enter no. of instances  : ')
    inst8=int(inst8)
    kanta = inst8
    head = input("Time of delay (in seconds) : ")
    checkproxy = input("1.proxy,   2.noproxy :  ")
    timeee()
